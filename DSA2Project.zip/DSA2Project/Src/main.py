import csv
import datetime
from trucks import *
from Src import package, hashtable, trucks
from hashtable import ChainingHashTable


def main():

    # Takes all data from the Package File and stores it in a list
    with open(r"C:\Users\pharr\PycharmProjects\DSA2Project\ProjectData\WGUPS Package File.csv", newline='') as packagedata:
        packageTable = [row for row in csv.reader(packagedata, delimiter=',')]

    # Takes all data from the XAxisOfTable file and stores it in a list
    with open(r"C:\Users\pharr\PycharmProjects\DSA2Project\ProjectData\XAxisOfTable.csv", newline='') as xaxisdata:
        xaxisheaders = []
        reader = csv.reader(xaxisdata, delimiter=',')
        for entry in reader:
            xaxisheaders.append(entry)

    # Takes all data from the YAxisOfTable file and stores it in a list
    with open(r"C:\Users\pharr\PycharmProjects\DSA2Project\ProjectData\YAxisOfTable.csv", newline='') as yaxisdata:
        yasxisheaders = []
        reader = csv.reader(yaxisdata, delimiter=',')
        for entry in reader:
            yasxisheaders.append(entry)

    # Takes all data from the Distance Table file and stores it in a list
    with open(r"C:\Users\pharr\PycharmProjects\DSA2Project\ProjectData\WGUPS Distance Table.csv", newline='') as distancedata:
        distancedatatable = []
        reader = csv.reader(distancedata, delimiter=',')
        for entry in reader:
            distancedatatable.append(entry)

            print(packageTable)

    packageList = []
    packageObjectList = []

    #for i in range(len(packageTable)):
     #   packageInfo = dict(package_id=int(packageTable[i][0]), address=packageTable[i][1], city=packageTable[i][2],
      #                     state=packageTable[i][3], zip=packageTable[i][4], deadline=packageTable[i][5],
       #                    weight=packageTable[i][6], notes=packageTable[i][7])
        #packageList.append(packageInfo)
        #packageObjectList.append(packageClass.Package())




run = True
main()
