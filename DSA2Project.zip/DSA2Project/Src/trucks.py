import csv
import datetime

from Src import graph


class Truck:
    # Truck object constructor -> space complexity = O(N); time complexity = O(1)
    def __init__(self):
        self.truckNum = 0
        self.max_packages = 16
        self.avg_speed = 18  # this is in mph
        self.packagesOnTruck = []  # this lists all the packages on the truck
        self.milesTraveled = 0  # initial distance traveled is 0 since it starts at the hub
        self.locationsVisited = []  # this helps determine where the truck has been
        self.departed = False  # truck starts at hub
        self.pathGraph = graph.Graph()  # graph that depicts where the truck is going to go
        self.departureTime = datetime.datetime.strptime("08:00 AM", "%I:%M %p")
        self.truckTime = self.departureTime
        self.timeLeftHub = self.departureTime



