class Package:

    def __init__(self, packageId, address, city, state, zip,  weight, deadline):
        self.packageId = packageId
        self.address = address
        self.weight = weight
        self.deadline = deadline
        self.priority = None
        self.left_hub = None
        self.delivered_at = None
        self.truck = None

    def __hash__(self):
        return hash(self.id)

