# Constraints
# 1 truck can only carry 16 packages
# trucks travel at 18 mph - this speed includes delivery time and truck loading times
# distance between stops disregards collision of objects
# 3 trucks/2 drivers
# the delivery routes begin at 8am and drivers may return
# packages may contain 1 <= special notes
# day ends when no more packages are left to deliver

